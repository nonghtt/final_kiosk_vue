<template lang="">
    <div>
        

     
        
        
    </div>
    </div>
</template>
<script>
export default {
    
}
</script>
<style lang="">
body{
    margin:0
}

    .payment_window{
    background-color: rgba(0,0,0,0.5);
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width:500px;
    height:500px;
    border-radius: 30px;
}
.payment_modal{
    background-color:white;
}
</style>